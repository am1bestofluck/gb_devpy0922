Denumirea intrepr   **"S.C. Lumsitas" S.R.L.**

Denumirea taxoparc **LUMSITAS**

Cod fiscal **1004600017689**

adresa j **m.Chisinau, str. V. Alecsandri 117/1**

adresa f **m.Chisinau, str. P. Rares 62**

telefon **079 935 860**

email **None**

|nr. tarif|PORNIRE|leu/km|stationare, leu/ora| mesaj|
|-|-|-|-|-|
|1 de zi| 25|5|60|T1,STANDART|
2 de noapte|25|5|60|T1,STANDART|
|3 de zi| 40|5|60|T2,STANDART+15/COMFORT|
|4 de noapte| 40|5|60|T2,STANDART+15/COMFORT|
|5 de zi| 55|7|60|T3,STANDART+30/COMFORT+15,|
|6 de noapte| 55|7|60|T3, STANDART+30/COMFORT+15, in afara orasului|
|7 de zi| 70|9|60|T4,STANDART+45/COMFORT+30, in afara orasului, Business|
|8 de noapte| 70|9|60|T4,STANDART+45/COMFORT+30, in afara orasului, Business|

marime TVA, % **0**

AUTOMOBIL: MARCA, MODEL **NISSAN QASHQAI +2**

NUMAR DE INMATRICULARE **MLD 571**

SOFERI:

    NR1:

        NUME PRENUME: CHIPERCEANU DUMITRU
        PAROLA: 1111

TAXIMETRU: ELITAX-TA 100 MOL **006829**
TRADUCTOR: 